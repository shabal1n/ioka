from ioka.entities.order import Order
from ioka.entities.payment import Payment
from ioka.entities.customer import Customer
from ioka.entities.card import Card
from ioka.entities.webhook import Webhook
from ioka.entities.dashboard import Dashboard

hostname = 'https://stage-api.ioka.kz'
api_key = None